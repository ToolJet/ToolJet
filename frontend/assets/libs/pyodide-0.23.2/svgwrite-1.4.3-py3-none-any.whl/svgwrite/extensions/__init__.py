# Copyright (c) 2018 Manfred Moitzi
# License: MIT License
from .inkscape import Inkscape
