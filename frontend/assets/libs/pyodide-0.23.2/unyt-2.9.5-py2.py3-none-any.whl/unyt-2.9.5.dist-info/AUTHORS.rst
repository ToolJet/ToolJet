=======
Credits
=======

Contributors
------------

* Ricarda Beckmann <ricarda.beckmann@astro.ox.ac.uk>
* Andrei Berceanu <andreiberceanu@gmail.com>
* Josh Borrow <joshua.borrow@durham.ac.uk>
* Yi-Hao Chen <ychen@astro.wisc.edu>
* Bili Dong <qobilidop@gmail.com>
* Nathan Goldbaum <nathan12343@gmail.com>
* David Hannasch <David.A.Hannasch@gmail.com>
* Cameron Hummels <chummels@gmail.com>
* Thomas Hisch <t.hisch@gmail.com>
* Paul Ivanov <pivanov5@bloomberg.net>
* Suoqing Ji <jisuoqing@gmail.com>
* Lee Johnston <lee.johnston.100@gmail.com>
* Ben Kimock <kimockb@gmail.com>
* Kacper Kowalik <xarthisius.kk@gmail.com>
* Nathan Musoke <nathan.musoke@gmail.com>
* Andrew Myers <atmyers2@gmail.com>
* Clément Robert
* Simon Schopferer <simon.schopferer@dlr.de>
* Sam Skillman <samskillman@gmail.com>
* Britton Smith <brittonsmith@gmail.com>
* Josh Soref
* Kyle Sunden <sunden@wisc.edu>
* Ben Thompson
* Matthew Turk <matthewturk@gmail.com>
* Miguel de Val-Borro <miguel.deval@gmail.com>
* John ZuHone <jzuhone@gmail.com>
* Kyle Oman
* Osnippet

This library was adapted from `dimensionful
<https://github.com/caseywstark/dimensionful>`_ which was written by Casey Stark
<caseystark@gmail.com>.
